// For now, no additional logic is required.
// You can add extra UI interactions later if needed.

console.log("Face Attendance System loaded");
