import os
import pickle
import numpy as np
import cv2
import face_recognition
import cvzone
import firebase_admin
from firebase_admin import credentials, db
from datetime import datetime, timedelta
from flask import Flask, render_template, Response

# Initialize Firebase
cred = credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': "https://faceattendancerealtimeda-39bfc-default-rtdb.firebaseio.com/"
})

# Flask app
app = Flask(__name__)

# Video capture
cap = cv2.VideoCapture(0)
cap.set(3, 640)
cap.set(4, 480)

# Background and modes
imgBackground = cv2.imread('Resources/background.png')
folderModePath = 'Resources/Modes'
imgModeList = sorted(
    [cv2.imread(os.path.join(folderModePath, path)) for path in os.listdir(folderModePath)],
    key=lambda x: x.shape[0] if x is not None else 0
)

# Load encodings
print("Loading Encode File ...")
with open('EncodeFile.p', 'rb') as file:
    encodeListKnown, studentIds = pickle.load(file)
print("Encode File Loaded")

# State variables
modeType = 0  # 0 = active, 1 = info, 2 = marked, 3 = already marked
id = -1
imgStudent = []
studentInfo = {}
display_start_time = None
marked_start_time = None
last_marked_times = {}  # {student_id: datetime}


def generate_frames():
    global modeType, id, imgStudent, studentInfo, display_start_time, marked_start_time, last_marked_times

    while True:
        success, img = cap.read()
        if not success:
            continue

        imgS = cv2.resize(img, (0, 0), None, 0.25, 0.25)
        imgS = cv2.cvtColor(imgS, cv2.COLOR_BGR2RGB)

        faceCurFrame = face_recognition.face_locations(imgS)
        encodeCurFrame = face_recognition.face_encodings(imgS, faceCurFrame)

        imgBackground[162:162 + 480, 55:55 + 640] = img

        # Mode timers
        if modeType == 1 and display_start_time and (datetime.now() - display_start_time).total_seconds() > 5:
            modeType = 2  # switch to marked page
            marked_start_time = datetime.now()

        if modeType in [2, 3] and marked_start_time and (datetime.now() - marked_start_time).total_seconds() > 2:
            modeType = 0  # reset to active
            id = -1
            imgStudent = []
            studentInfo = {}
            display_start_time = None
            marked_start_time = None

        imgBackground[44:44 + 633, 808:808 + 414] = imgModeList[modeType]

        if faceCurFrame and modeType == 0:
            for encodeFace, faceLoc in zip(encodeCurFrame, faceCurFrame):
                matches = face_recognition.compare_faces(encodeListKnown, encodeFace)
                faceDis = face_recognition.face_distance(encodeListKnown, encodeFace)
                matchIndex = np.argmin(faceDis)

                if matches[matchIndex]:
                    id = studentIds[matchIndex]
                    now = datetime.now()

                    # Fetch student info
                    studentInfo = db.reference(f'Students/{id}').get()

                    imgPath = f"Images/{id}.png"
                    imgStudent = cv2.imread(imgPath) if os.path.exists(imgPath) else np.zeros((216, 216, 3), dtype=np.uint8)

                    # Check if already marked within 30 seconds
                    if id in last_marked_times and (now - last_marked_times[id]).total_seconds() < 30:
                        modeType = 3  # already marked
                        marked_start_time = now
                    else:
                        # Update attendance
                        last_att_time = datetime.strptime(studentInfo['last_attendance_time'], "%Y-%m-%d %H:%M:%S")
                        if (now - last_att_time).total_seconds() > 30:
                            ref = db.reference(f'Students/{id}')
                            studentInfo['total_attendance'] += 1
                            ref.child('total_attendance').set(studentInfo['total_attendance'])
                            ref.child('last_attendance_time').set(now.strftime("%Y-%m-%d %H:%M:%S"))

                        last_marked_times[id] = now
                        modeType = 1  # info page
                        display_start_time = now

        # Display student info only in modeType 1
        if modeType == 1 and studentInfo:
            cv2.putText(imgBackground, str(studentInfo['total_attendance']), (861, 125),
                        cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 1)
            cv2.putText(imgBackground, str(studentInfo['major']), (1006, 550),
                        cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 255), 1)
            cv2.putText(imgBackground, str(id), (1006, 493),
                        cv2.FONT_HERSHEY_COMPLEX, 0.5, (255, 255, 255), 1)
            cv2.putText(imgBackground, str(studentInfo['standing']), (910, 625),
                        cv2.FONT_HERSHEY_COMPLEX, 0.6, (100, 100, 100), 1)
            cv2.putText(imgBackground, str(studentInfo['year']), (1025, 625),
                        cv2.FONT_HERSHEY_COMPLEX, 0.6, (100, 100, 100), 1)
            cv2.putText(imgBackground, str(studentInfo['starting_year']), (1125, 625),
                        cv2.FONT_HERSHEY_COMPLEX, 0.6, (100, 100, 100), 1)

            (w, h), _ = cv2.getTextSize(studentInfo['name'], cv2.FONT_HERSHEY_COMPLEX, 1, 1)
            offset = (414 - w) // 2
            cv2.putText(imgBackground, str(studentInfo['name']), (808 + offset, 445),
                        cv2.FONT_HERSHEY_COMPLEX, 1, (50, 50, 50), 1)

            imgBackground[175:175 + 216, 909:909 + 216] = imgStudent

        ret, buffer = cv2.imencode('.jpg', imgBackground)
        frame = buffer.tobytes()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')


if __name__ == '__main__':
    app.run(debug=True)
